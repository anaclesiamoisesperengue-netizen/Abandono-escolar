const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.textContent = isOpen ? '✕' : '☰';
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open'); menuButton.setAttribute('aria-expanded','false'); menuButton.textContent='☰';
}));

const questions = [
 {q:'O que é o abandono escolar?',a:['Mudar de turma dentro da mesma escola.','Interromper os estudos antes de concluir o nível de ensino.','Faltar a uma aula por motivo de saúde.'],correct:1,why:'Correcto! O abandono escolar é a interrupção dos estudos antes da conclusão do nível frequentado.'},
 {q:'Qual destas situações pode contribuir para o abandono escolar?',a:['Dificuldades económicas e trabalho infantil.','Apoio dos professores.','Um ambiente escolar seguro.'],correct:0,why:'Muito bem. A pobreza e a necessidade de trabalhar podem dificultar a frequência escolar.'},
 {q:'O que pode ser uma consequência do abandono escolar?',a:['Mais oportunidades garantidas.','Aumento automático das notas.','Menos oportunidades de formação e emprego.'],correct:2,why:'Exactamente. A interrupção dos estudos pode limitar o acesso a formação e a oportunidades profissionais.'},
 {q:'Qual é uma medida de prevenção?',a:['Ignorar faltas repetidas.','Identificar dificuldades cedo e apoiar o aluno.','Humilhar quem tem notas baixas.'],correct:1,why:'Certo! O acompanhamento, o diálogo e o apoio precoce ajudam a prevenir a desistência.'}
];
let current=0, score=0, answered=false;
const qEl=document.getElementById('question'), answersEl=document.getElementById('answers');
const feedback=document.getElementById('feedback'), next=document.getElementById('next-question');
function renderQuestion(){
 const item=questions[current]; answered=false;
 document.getElementById('question-count').textContent=`PERGUNTA ${current+1} DE ${questions.length}`;
 document.getElementById('score-label').textContent=`Pontuação: ${score}`;
 document.getElementById('progress-bar').style.width=`${(current+1)/questions.length*100}%`;
 qEl.textContent=item.q; feedback.textContent=''; next.disabled=true;
 next.textContent=current===questions.length-1?'Ver resultado →':'Próxima pergunta →';
 answersEl.innerHTML='';
 item.a.forEach((answer,index)=>{
  const button=document.createElement('button'); button.className='answer'; button.textContent=answer;
  button.addEventListener('click',()=>selectAnswer(index)); answersEl.appendChild(button);
 });
}
function selectAnswer(index){
 if(answered)return; answered=true;
 const item=questions[current], buttons=[...answersEl.children];
 buttons.forEach((button,i)=>{button.disabled=true;if(i===item.correct)button.classList.add('correct');else if(i===index)button.classList.add('wrong');});
 if(index===item.correct){score++;feedback.textContent='✓ '+item.why;feedback.style.color='#398765';}
 else{feedback.textContent='Ainda não. '+item.why;feedback.style.color='#d96854';}
 document.getElementById('score-label').textContent=`Pontuação: ${score}`;next.disabled=false;
}
next.addEventListener('click',()=>{
 if(!answered)return;
 if(current<questions.length-1){current++;renderQuestion();}
 else{qEl.textContent=`Terminaste! Acertaste ${score} de ${questions.length} perguntas.`;answersEl.innerHTML='';feedback.textContent=score===4?'Excelente! Mostraste que compreendeste muito bem o tema.':'Bom esforço! Revê as secções do website e tenta novamente.';feedback.style.color='#398765';next.disabled=true;next.textContent='Desafio concluído';}
});
document.getElementById('restart-quiz').addEventListener('click',()=>{current=0;score=0;renderQuestion();});
renderQuestion();
